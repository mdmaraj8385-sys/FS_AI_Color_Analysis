import os, tempfile
from pathlib import Path
import httpx, cv2
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE = Path(__file__).resolve().parent.parent
FRONTEND = BASE / "frontend"
MAX_VIDEO_BYTES = int(os.getenv("MAX_VIDEO_MB", "40")) * 1024 * 1024
origins = [x.strip() for x in os.getenv("ALLOWED_ORIGINS", "http://127.0.0.1:8000,http://localhost:8000").split(",") if x.strip()]
app = FastAPI(title="FS AI Color Analysis", version="3.0.0")
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False, allow_methods=["GET","POST"], allow_headers=["Content-Type","Authorization"])

class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    history: list[dict] = Field(default_factory=list, max_length=12)

class AnalysisIn(BaseModel):
    numbers: list[int] = Field(min_length=1, max_length=1000)
    small_max: int = Field(default=4, ge=0, le=8)

def fallback(msg):
    if any(x in msg.lower() for x in ["big","small","বিগ","স্মল","কালার"]):
        return "যাচাইকৃত অতীত ফলাফল দিলে আমি অনুপাত ও প্যাটার্ন বিশ্লেষণ করতে পারি। তবে পরের ফল নিশ্চিতভাবে বলা সম্ভব নয়।"
    return "এখন AI provider configure করা নেই। বাস্তব কথোপকথনের জন্য backend environment-এ AI_BASE_URL, AI_API_KEY এবং AI_MODEL সেট করুন।"

@app.get("/api/health")
async def health():
    return {"ok": True, "ai_configured": bool(os.getenv("AI_BASE_URL") and os.getenv("AI_MODEL")), "version": "3.0.0"}

@app.post("/api/chat")
async def chat(req: ChatIn):
    base, key, model = os.getenv("AI_BASE_URL","").rstrip("/"), os.getenv("AI_API_KEY",""), os.getenv("AI_MODEL","")
    if not base or not model:
        return {"reply": fallback(req.message), "mode":"demo_fallback"}
    messages=[{"role":"system","content":"তুমি FS AI Color Analysis-এর বাংলা সহকারী। প্রশ্নের উত্তর স্পষ্ট ও সতর্কভাবে দাও। Big/Small গেমের পরবর্তী ফল নিশ্চিত বলে দাবি করবে না। ভিডিও/OCR তথ্য ভুল হতে পারে বলে যাচাই করতে বলবে।"}]
    for x in req.history[-10:]:
        if x.get("role") in ("user","assistant") and isinstance(x.get("content"),str):
            messages.append({"role":x["role"],"content":x["content"][:4000]})
    messages.append({"role":"user","content":req.message})
    headers={"Content-Type":"application/json"}
    if key: headers["Authorization"]="Bearer "+key
    url=base if base.endswith("/chat/completions") else base+"/chat/completions"
    try:
        async with httpx.AsyncClient(timeout=45) as client:
            r=await client.post(url,headers=headers,json={"model":model,"messages":messages,"temperature":0.4})
            r.raise_for_status()
            return {"reply":str(r.json()["choices"][0]["message"]["content"])[:12000],"mode":"configured_ai"}
    except Exception:
        raise HTTPException(502,"AI provider সংযোগ ব্যর্থ; server settings যাচাই করুন।")

@app.post("/api/analyze")
async def analyze(req: AnalysisIn):
    if any(n<0 or n>9 for n in req.numbers): raise HTTPException(400,"সংখ্যা 0–9 হতে হবে।")
    nums=req.numbers; small=sum(n<=req.small_max for n in nums); big=len(nums)-small
    return {"count":len(nums),"big_count":big,"small_count":small,"big_percent":round(big/len(nums)*100,1),"small_percent":round(small/len(nums)*100,1),"interpretation":"Big বেশি" if big>small else ("Small বেশি" if small>big else "সমান"),"warning":"অতীত ডেটার বর্ণনা; পরের ফল নিশ্চিত করে না।"}

@app.post("/api/video")
async def video(file: UploadFile = File(...)):
    name=(file.filename or "").lower()
    if not name.endswith((".mp4",".mov",".webm",".m4v",".avi")): raise HTTPException(415,"সমর্থিত ভিডিও ফাইল দিন।")
    path=None
    try:
        with tempfile.NamedTemporaryFile(delete=False,suffix=Path(name).suffix) as f:
            path=Path(f.name); size=0
            while True:
                chunk=await file.read(1024*1024)
                if not chunk: break
                size+=len(chunk)
                if size>MAX_VIDEO_BYTES: raise HTTPException(413,"ভিডিও 40 MB সীমার মধ্যে রাখুন।")
                f.write(chunk)
        cap=cv2.VideoCapture(str(path))
        if not cap.isOpened(): raise HTTPException(400,"ভিডিও পড়া যায়নি।")
        fps=cap.get(cv2.CAP_PROP_FPS) or 0; count=cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
        duration=count/fps if fps else 0
        if duration>300: cap.release(); raise HTTPException(413,"সর্বোচ্চ 5 মিনিটের ভিডিও সমর্থিত।")
        times=[0] if duration<=0 else sorted(set([round(i*duration/4,2) for i in range(5)]))
        frames=[]
        for t in times:
            cap.set(cv2.CAP_PROP_POS_MSEC,t*1000); ok,fr=cap.read()
            if ok: frames.append({"time_seconds":t,"width":int(fr.shape[1]),"height":int(fr.shape[0])})
        cap.release()
        return {"filename":Path(name).name,"size_bytes":size,"duration_seconds":round(duration,2),"frames_sampled":frames,"ocr_available":False,"ocr_text":"","note":"এই starter সংস্করণে সার্ভার-side OCR চালু নেই; OCR পরবর্তী ধাপে যোগ করা যাবে।"}
    finally:
        await file.close()
        if path and path.exists():
            try: path.unlink()
            except OSError: pass

@app.get("/")
async def index(): return FileResponse(FRONTEND/"index.html")
app.mount("/",StaticFiles(directory=str(FRONTEND),html=True),name="frontend")
