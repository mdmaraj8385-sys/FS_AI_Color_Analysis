# FS AI Color Analysis v3 — Floating Assistant + Full-screen Website

## নতুন কী
- একই স্ক্রিনে Big/Small analysis এবং floating AI chat
- নিজের পছন্দের website URL যোগ/সংরক্ষণ
- Website panel-এর মধ্যে fullscreen-style browsing চেষ্টা
- AI window ছোট/বড় করা ও স্ক্রিনে টেনে সরানো
- browser voice input/output support থাকলে microphone ও speak
- video upload API integration আগের v2 starter-এর মতো
- Python backend-এ AI provider key রাখার ব্যবস্থা

## গুরুত্বপূর্ণ সীমাবদ্ধতা
1. কোনো বাইরের website `X-Frame-Options` বা CSP `frame-ancestors` দিয়ে embedding বন্ধ করলে অ্যাপের ভেতরে খুলবে না। তখন "নতুন ট্যাবে খুলুন" ব্যবহার করতে হবে।
2. অন্য Android অ্যাপ বা Chrome-এর বাইরে floating window দেখানো সাধারণ website/PWA পারে না। Android-এর ওপর ভাসমান system-wide window করতে হলে আলাদা native Android app ও special overlay permission লাগবে।
3. iframe-এ খোলা site নিজের login, cookies, payment, camera বা location feature ঠিকমতো নাও চালাতে পারে।
4. Big/Small statistics অতীতের ডেটা বর্ণনা করে; পরের ফল নিশ্চিত করে না।
5. Video OCR ঐচ্ছিক এবং OCR ভুল হতে পারে।
6. Public release-এর আগে authentication, rate limits, HTTPS, upload validation, privacy notice ও data retention policy যোগ করুন।

## চালানো (Android / Termux)
ZIP Extract করুন। Termux-এ:
```bash
pkg update
pkg install python
cd ~/storage/downloads/FS_AI_Color_Analysis_v3_Floating_Assistant/backend
pip install -r requirements.txt
uvicorn main:app --host 127.0.0.1 --port 8000
```
তারপর Chrome-এ `http://127.0.0.1:8000` খুলুন।
ZIP অন্য ফোল্ডারে Extract করলে `cd` path বদলান।

## আসল AI
Backend-এ `.env.example` অনুযায়ী `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL` environment variables সেট করুন। API key কখনো frontend JavaScript-এ লিখবেন না। Provider-এর free quota এবং terms পরিবর্তন হতে পারে।

## Website link
Link Manager-এ HTTPS URL যোগ করুন। কিছু website iframe embedding বন্ধ রাখে। সে ক্ষেত্রে external tab button দিয়ে খুলুন। Android Chrome-এর বাইরে floating chat দেখানো সম্ভব নয়; এই app-এর নিজের webpage-এর ভেতরেই floating assistant কাজ করে।
